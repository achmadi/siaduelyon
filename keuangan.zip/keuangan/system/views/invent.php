<?php require_once(MODDIR.'gpage.php');

gpage_tabs_singlebox('Penerimaan barang:inventory_penerimaan.php','Daftar barang:inventory.php','Inventory Sarana Prasarana:inventory_sarpras.php');
?>
