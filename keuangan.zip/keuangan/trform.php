<?php
require_once('../shared/config.php');
require_once('system/config.php');
require_once(DBFILE);
require_once(LIBDIR.'common.php');
require_once(SHAREDDIR.'photoform.php');
?>