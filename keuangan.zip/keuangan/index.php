<?php 
	session_start(); 
	require_once('../shared/config.php');
	require_once('system/config.php');
	require_once(SHAREDFW);
?>